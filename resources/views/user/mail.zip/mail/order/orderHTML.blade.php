<h1>Заказ № {{$order->id}}</h1>
<table class="table table-hover">
    <tbody>
    <tr class="table__header">
        <th>Наименование</th>
        <th>Цвет</th>
        <th>Размер</th>
        <th>Количество</th>
        <th>Цена</th>
        <th>Фио заказчика</th>
        <th>Телефон заказчика</th>
        <th>Почта заказчика</th>
    </tr>
    <tr>
        <th>{{$order->t_shirt_name}}</th>
        <td>{{$order->t_shirt_color}}</td>
        <td>{{$order->t_shirt_size}}</td>
        <td>{{$order->t_shirt_qty}}</td>
        <td>{{$order->t_shirt_totalPrice}}</td>
        <td>{{$order->customer_name}}</td>
        <td>{{$order->customer_phone}}</td>
        <td>{{$order->customer_email}}</td>
    </tr>
    </tbody>
</table>
<p>
    С уважением, {{env('APP_NAME')}}.by
</p>