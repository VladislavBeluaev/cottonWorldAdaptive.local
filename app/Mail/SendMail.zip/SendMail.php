<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(Model $model)
    {
        $this->model = $model;
        $this->test = [0,1,2];
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from(env('MAIL_USERNAME'),env('APP_NAME'))
            ->subject("Поступил новый заказ")
            ->view('user.mail.order.orderHTML')
            ->text('user.mail.order.orderPlain')
            ->with([ 'order' => $this->model]);
    }
    protected $model;
    protected $test;
}
